// localStorage.js
/* Later we will be using Classes and loading student data from external data file */
